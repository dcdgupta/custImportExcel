package com.ftl.custImportExcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustImportExcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
