package com.ftl.custImportExcel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustImportExcelApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustImportExcelApplication.class, args);
	}

}
